
$(document).on('click', '.dropdown-toggle', function() {
  $('#sidebarCollapse li ul').removeClass('show');
  // console.log(this)
  $(this).next('ul').toggleClass('show');
});

$(document).on('click', '#sidebar li a', function() {
  $('a[aria-expanded]').attr('aria-expanded', 'false');
  $(this).parent().addClass('active').siblings().removeClass('active');
});
$(document).on('click', '#livetv-sec-tab' , function(){
  $("#live-tv-div-hide-show").toggle("");
  $("#livetv-sec-tab").toggleClass("active");
});
$(function () {
  $('[data-toggle="tooltip"]').tooltip()
})


$(document).on('click', '#mobile-sidebar' , function(){
  $('ul').removeClass('show');
  $("#sidebar").toggleClass("active");
});

$(document).on('click', '.back_layer' , function(){
  $("#sidebar").removeClass("active");
});

$(document).on('click', '.top-header' , function(){
  $("#sidebar").removeClass("active");
});

$(document).on('click', '.close-side' , function(){
  $("#sidebar").removeClass("active");
});
$(document).on('click', '#mobile-match-unmatch-data' , function(){
  $(".matched-unmetched-data-mobile").toggle("slow");
});
$(document).on('click', '.back-rate-open-slip' , function(evt){
  evt.stopPropagation();
  $(".betting-slip-section-class").addClass("show");
  $(".betting-slip-section").addClass("d-block");
});
$(document).on('click', '.lay-rate-open-slip' , function(){
  $(".betting-slip-section-class").addClass("show");
  $(".betting-slip-section").addClass("d-block");
});
$(document).on('click', '.back-rate-open-slip' , function(){
  $(".betting-slip-div-class").addClass("betting-slip-back");
  // $(".betting-slip-div-class").removeClass("betting-slip-lay");
});
$(document).on('click', '.lay-rate-open-slip' , function(){
  $(".betting-slip-div-class").addClass("betting-slip-lay");
  // $(".betting-slip-div-class").removeClass("betting-slip-back");
});

$(document).on('click', '.dropdown-toggle.betting-slip' , function(){
  $(".betting-slip-section.d-block").toggleClass("d-block");
});
$('body,html').click(function (e) {
  var container = $(".betting-slip-section-class");
  if (!container.is(e.target) && container.has(e.target).length === 0) {
    // container.removeClass('show');
  }
  var container = $(".betting-slip-section");
  if (!container.is(e.target) && container.has(e.target).length === 0) {
    // container.removeClass('d-block');
  }
});

// $('#oddsInput').prop('disabled', true);
$(document).on('click', '#plus-btn' , function(){
  $('#oddsInput').val(parseInt($('#oddsInput').val()) + 1 );
});
$(document).on('click', '#minus-btn' , function(){
  $('#oddsInput').val(parseInt($('#oddsInput').val()) - 1 );
  if ($('#oddsInput').val() == 0) {
    $('#oddsInput').val(1);
  }
});
// $('#stackInput').prop('disabled', true);
$(document).on('click', '#plus-btn1' , function(){
  $('#stackInput').val(parseInt($('#stackInput').val()) + 1 );
});
$(document).on('click', '#minus-btn1' , function(){
  $('#stackInput').val(parseInt($('#stackInput').val()) - 1 );
  if ($('#stackInput').val() == 0) {
    $('#stackInput').val(1);
  }
});


// Fancy Cart JS
// $(document).on('click', '#chart_btn' , function(evt){
//   evt.stopPropagation();

// });
$(document).on('click', '#ChartCloseBtn' , function(evt){
  $(".fancy-main-chart-div").removeClass("active");
});
$('body,html').click(function (e) {
  var container = $(".fancy-main-chart-div");
  if (!container.is(e.target) && container.has(e.target).length === 0) {
    container.removeClass('active');
  }
});
$('.nav-tabs-dropdown')
  .on("click", "li:not('.active') a", function(event) {  $(this).closest('ul').removeClass("open");
  })
  .on("click", "li.active a", function(event) {        $(this).closest('ul').toggleClass("open");
  });

$(document).on('click', '.user-main' , function(e){
  if ($(".side-bar").hasClass("is-open")) {
    $('.side-bar').removeClass('is-open');
  }
  $('.user-main').toggleClass('profile-open');
});

$(document).on('click', 'li' , function(e){
  $("li").removeClass("open");
  $(this).toggleClass("open");
});


$(document).on('click', '.activeClass' , function(e){
  $('.activeClass').removeClass("active_cls");
  $(this).addClass("active_cls");
});

$(document).on('click', '#mymenu' , function(e){
  $(this).toggleClass("open");
  $('.side-bar').toggleClass('is-open')
});

$(document).on('click', '.sidebar-menu-icon' , function(e){
    $('.side-bar').toggleClass('is-open');
});

