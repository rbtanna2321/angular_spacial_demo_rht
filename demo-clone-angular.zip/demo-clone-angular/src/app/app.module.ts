import { BrowserModule } from '@angular/platform-browser';
import {CUSTOM_ELEMENTS_SCHEMA, NgModule} from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {LoginComponent} from './login/login.component';
import {HeaderComponent} from './header/header.component';
import {SidebarComponent} from './sidebar/sidebar.component';
import {SocketService} from './globals/socketService';
import {SocketServiceClient} from './globals/socketServiceClient';
import {SocketServiceBbMarket} from './globals/socketServiceBbMarket';
import {SocketServiceRedis} from './globals/socketServiceRedis';
import {SocketServiceRedisMarket} from './globals/socketServiceRedisMarket';
import {SocketServiceDotnetStock} from './globals/socketServiceDotnetStock';
// import {NgxSpinnerService} from 'ngx-spinner';
import {UtilityService} from './globals/utilityService';
import {AuthGuard} from './auth-gaurd/auth-guard.service';
import {HTTP_INTERCEPTORS, HttpClientModule} from '@angular/common/http';
import {DefaultRequestOptions} from './auth-gaurd/default-request-options.provider';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {FormsModule} from '@angular/forms';
import {ToasterModule} from 'angular2-toaster';
import {ModalModule} from 'ngx-bootstrap/modal';
import {commonDerectivenModule} from './auth-gaurd/commonDerective.module';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    // DashboardComponent,
    HeaderComponent,
    SidebarComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    HttpClientModule,
    FormsModule,
    ToasterModule.forRoot(),
    ModalModule.forRoot(),
    commonDerectivenModule,
  ],
  providers: [
    SocketService,
    SocketServiceClient,
    SocketServiceBbMarket,
    SocketServiceRedis,
    //SocketcasinoRedis,
    SocketServiceRedisMarket,
    SocketServiceDotnetStock,
    // NgxSpinnerService,
    UtilityService,
    AuthGuard ,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: DefaultRequestOptions,
      multi: true
    },
  ],
  bootstrap: [AppComponent],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ]
})
export class AppModule { }
