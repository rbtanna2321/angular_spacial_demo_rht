'use strict';
import {SocketService} from "../globals/socketService";

declare var require: any;
import { Component, OnInit,ViewChild } from '@angular/core';
import {Route, Router} from '@angular/router';
import * as env from '../globals/env';
import { CommonService } from '../services/common.service';
import { UserService } from '../services/user.service';
import {SocketServiceClient} from "../globals/socketServiceClient";
var aes256 = require('aes256');
import { UtilityService } from '../globals/utilityService';
import {environment} from '../../environments/environment';
// import {ModalDirective} from 'ngx-bootstrap';
import * as $ from 'jquery';
// import {NgxSpinnerService} from "ngx-spinner";
import {SocketServiceRedis} from '../globals/socketServiceRedis';


declare let _: any;

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  // @ViewChild("loginForm", { static: false }) loginForm;
  // @ViewChild('loginModal', { static: false }) loginModal: ModalDirective;
  // @ViewChild('passwordChange', { static: false }) passwordChange: ModalDirective;
  // @ViewChild("registerForm", { static: false }) registerForm;
  // @ViewChild('registerModal', { static: false }) registerModal: ModalDirective;
  // @ViewChild('otpModal', { static: false }) otpModal: ModalDirective;

  logo: any = env.PROJECT_LOGO_URL;
  oldPassword: any;
  newPassword: any;
  bannerImages: any;
  casinoImages: any;
  confNewPassword: any;
  loginObject = {
    userName: null,
    password: null,
    deviceId : "",
    fcmToken : "",
    channel : "WEB",
    userType : "CLIENT"
  };
  registerObject = {
    userName: null,
    fullName:null,
    password: null,
    channel : "WEB",
    userType : "CLIENT",
    dialCode : "91",
    countryName : "India (भारत)",
    mobileNo : '',
    emailId : ''
  };
  showPassword = false;
  showPassword1 = false;
  showPassword2 = false;
  Toast = {
    type: '',
    title: '',
    timeout: 0,
    body: ''
  };
  endSubmit = false;
  stockUsernamePrefix = env.stockUsernamePrefix();
  refralCode = false;
  countryCode = {
    dialCode: "91",
    iso2: "in",
    name: "India (भारत)"
  }
  otpuserId;
  loginPassword;
  loginUsername;
  countdown: number;
  stopCount  = false;
  constructor( private router: Router,
    private commonService: CommonService,
    private socketService: SocketService,
    private socketServiceClient: SocketServiceClient,
    private socketServiceRedis: SocketServiceRedis,
    private utilityService: UtilityService ,
    private userService:UserService,
    // private spinner : NgxSpinnerService
    ) { }

  ngOnInit() {
    $('.loading').hide();
    localStorage.clear();
    $('#mode').attr("href", 'assets/scss/custome-dark.css');
    this.socketService.disconnect();
    this.socketServiceClient.disconnect();
    this.socketServiceRedis.disconnect();
    let data = JSON.parse(this.utilityService.returnLocalStorageData('userData'));
    if (!this.utilityService.returnLocalStorageData('userId')) {
    } else {
      if(data && data.userType === 'CLIENT'){
        localStorage.clear();
         // this.router.navigate(['/dashboard']);
      }
    }
    // this.getBannerImage();
  }

  getBannerImage(){
    // this.marketService.getBannerImage().subscribe(response => {
    //   // response = this.utilityService.gsk(response.auth);
    //   // response = JSON.parse(response);
    //   if (response.status) {
    //     this.bannerImages = _.filter(response.data , function (e) {
    //       if(e.type === 'Banner'){
    //         return e;
    //       }
    //     });
    //     this.casinoImages = _.filter(response.data , function (e) {
    //       if(e.type === 'Casino'){
    //         return e;
    //       }
    //     });
    //     setTimeout(function(){
    //       $('.carousel-indicators > li').first().addClass('active');
    //       $('#img0').addClass('active');
    //     }, 200);
    //
    //   } else {
    //     // this.commonService.popToast('error','Error', 3000 , 'not found market rules.');
    //   }
    // }, error => {
    //   // this.commonService.popToast('error', 'Error', 3000, 'not found.');
    // });
  }
/*
  Developer: Ravi
  Date: 09-jan-2020
  title: Login method from backend
  Use: This function is use login from backend
*/

login() {
//   this.spinner.show();
//   if(this.endSubmit) {
//     return;
// }
// this.endSubmit = true;
//    let key = env.constantKey();
//   this.userService.loginApi(this.loginObject).subscribe(resposne =>{
//     this.endSubmit = false;
//     resposne = this.utilityService.gsk(resposne.auth);
//     resposne = JSON.parse(resposne);
//     if(resposne.status === true){
//
//       sessionStorage.setItem('balance', 'true');
//       sessionStorage.setItem('available', 'true');
//       sessionStorage.setItem('exposure', 'true');
//       sessionStorage.setItem('pl', 'true');
//       //this.showToster('Success','success', resposne.message);
//
//       var descryptJson = aes256.decrypt(key, resposne.data);
//       let resposne1 = JSON.parse(descryptJson);
//       let userData = JSON.stringify(resposne1);
//       let userId = resposne1.user_id;
//       let ip = resposne1.ipAddress;
//       let dateTime = resposne1.dateTime;
//       var userData1 = aes256.encrypt(key, userData);
//       var userId1 = aes256.encrypt(key, userId);
//       var ip1 = aes256.encrypt(key, ip);
//       var dateTime1 = aes256.encrypt(key, dateTime);
//       localStorage.setItem('userId', userId1);
//       sessionStorage.setItem('userId', userId1);
//       localStorage.setItem('token', resposne.token);
//       sessionStorage.setItem('token', resposne.token);
//       if(resposne1.changePassword === true){
//         localStorage.setItem('userData', userData1);
//         localStorage.setItem('ip', ip1);
//         localStorage.setItem('dateTime', dateTime1);
//
//         if(resposne1.allowStock != true){
//           this.loginModal.hide();
//           this.spinner.hide();
//           sessionStorage.setItem('theme', resposne1.themeName);
//           localStorage.setItem('theme', resposne1.themeName);
//           $('#mode').attr("href", resposne1.themeName);
//           this.router.navigate(['/dashboard']);
//         }
//
//       }else{
//         this.spinner.hide();
//         this.passwordChange.show();
//       }
//       sessionStorage.setItem('theme', resposne1.themeName);
//       localStorage.setItem('theme', resposne1.themeName);
//       $('#mode').attr("href", resposne1.themeName);
//       this.spinner.hide();
//       if(resposne1.changePassword === true){
//         this.router.navigate(['/dashboard']);
//       }
//     }
//   }, error =>{
//     this.spinner.hide();
//     let input = document.getElementById('userName');
//     input.focus();
//     this.loginObject.password = '';
//     this.loginForm.resetForm();
//     this.showToster('Error','error', error.error.message);
//   });
}



/*
    Developer: Ravi
    Date: 05-mar-2020
    title: Toster message
    Use: This function is use to throgh toster message
  */

 showToster(title,type,message){
  this.Toast.title = title;
  this.Toast.type = type;
  this.Toast.body = message;
  this.commonService.popToast(type, title, 1500, message)
}

  showPass(){
    this.showPassword = (this.showPassword === true) ?  false : true;
  }
  showPass1(){
    this.showPassword1 = (this.showPassword1 === true) ?  false : true;
  }
  showPass2(){
    this.showPassword2 = (this.showPassword2 === true) ?  false : true;
  }


  // closeLogin(){
  //   this.loginModal.hide();
  // }
  // closeModal(){
  //   this.passwordChange.hide();
  // }
  //
  // loginModalData(){
  //   this.loginModal.show();
  // }




}


