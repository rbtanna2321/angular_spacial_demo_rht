import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import { ToasterService, ToasterConfig, Toast } from 'angular2-toaster';
import * as env from '../globals/env';
import {UtilityService} from '../globals/utilityService';


@Injectable({
  providedIn: 'root'
})
export class CommonService {
  private headers = new HttpHeaders({'Authorization' : 'Bearer ' + this.utilityService.returnLocalStorageData('token')});
  private toasterService: ToasterService;

  server_url: any = env.server_url();

  constructor(private http: HttpClient, private utilityService: UtilityService ,
            toasterService: ToasterService
        ) {
          this.toasterService = toasterService;
        }

  log(message) {
    console.log(message);
  }

  public config1 : ToasterConfig = new ToasterConfig({
    positionClass: 'toast-bottom-right'
  });

  popToast(type,title ,timeout, body ) {
    const toast: Toast = {
      type: type,
      title: title,
      timeout: timeout,
      body: body
    };

    this.toasterService.pop(toast);
  }

  getLocalStorage(){
      let obj = {
       userData : this.utilityService.returnLocalStorageData('userData'),
       userId : this.utilityService.returnLocalStorageData('userId')
     }
      return obj;
  }

}
