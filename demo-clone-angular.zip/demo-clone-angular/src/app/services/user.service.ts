import { Injectable } from '@angular/core';
import {Observable} from 'rxjs/index';
import {HttpClient,HttpHeaders} from '@angular/common/http';
import {tap} from 'rxjs/internal/operators';
import * as env from '../globals/env';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  server_url: any = env.adminServer_url();

  constructor(private http: HttpClient) { }

    /**
   *@author Ravi Kadia
   * @date 09-01-2020
   * @param filter
   * @returns {Observable<any>}
   * add new user
   */

  loginApi(data): Observable<any> {
    return this.http.post(this.server_url + 'user/login' , data)
      .pipe(tap(_ => this.log(`user login successfully`)));
  }
  /**
   * @author TR
   * @date : 28/04
   * user logout function
   */


  logOut() :Observable<any>{
    return this.http.get(this.server_url + 'user/logout')
      .pipe(tap(_ => this.log(` user logout successfully`)));
  }

  log(message) {
    console.log(message);
  }
}
