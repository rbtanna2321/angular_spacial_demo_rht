import { Component, HostListener, OnInit, ViewChild } from '@angular/core';
declare let _: any;


@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  constructor() {}

  ngOnInit() {}

  userLogout() {
    // this.userService.logOut().subscribe(response => {
    //   response = this.utilityService.gsk(response.auth);
    //   response = JSON.parse(response);
    //   $("#mode").attr("href", 'assets/scss/custome-dark.css');
    //   this.commonService.popToast('success', 'Success', 1500, 'Logout successfully.');
    //   localStorage.clear();
    //   let lastJoinRoom = sessionStorage.getItem("lastJoinRoom");
    //
    //   let userJoinRoom = this.utilityService.returnSessionStorageData('userId');
    //   this.socketService.disconnect();
    //   this.socketServiceClient.disconnect();
    //   this.socketServiceRedis.disconnect();
    //   this.socketServiceBbMarket.disconnect();
    //   const oldEventId = sessionStorage.getItem('casinoId');
    //   if(oldEventId){
    //   //this.socketcasinoRedis.leaveRoom('casino_' + oldEventId);
    //   }
    //   if (lastJoinRoom) {
    //     this.socketService.leaveRoom(lastJoinRoom);
    //   }
    //   if (userJoinRoom) {
    //     this.socketServiceClient.leaveRoom(userJoinRoom);
    //   }
    //   sessionStorage.clear();
    //   this.router.navigate(['']);
    // }, error => {
    //   this.commonService.popToast('error', 'Error', 1500, error.message);
    //   console.error("error in logout");
    // });
  }

  // Pl(pl) {
  //   sessionStorage.setItem('pl', pl);
  //   let item = sessionStorage.getItem('pl');
  //   this.PlHideShow = JSON.parse(item);
  // }

}
